const users = 
[
  {
    "email": "melissa.fleming@example.com",
    "phone_number": "0740-304-475",
    "location": {
      "street": "3655 manchester road",
      "city": "winchester",
      "state": "berkshire",
      "postcode": "YB2 8EJ"
    },
    "first_name": "melissa",
    "last_name": "fleming"
  },
  {
    "email": "christoffer.christiansen@example.com",
    "phone_number": "05761325",
    "location": {
      "street": "3391 pilevangen",
      "city": "overby lyng",
      "state": "danmark",
      "postcode": 88520
    },
    "first_name": "christoffer",
    "last_name": "christiansen"
  }
]
module.exports = users;